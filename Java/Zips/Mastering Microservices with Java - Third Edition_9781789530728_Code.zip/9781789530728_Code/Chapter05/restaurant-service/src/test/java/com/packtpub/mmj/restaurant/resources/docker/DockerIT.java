package com.packtpub.mmj.restaurant.resources.docker;

/**
 *
 * @author Sourabh Sharma
 */
public interface DockerIT {
    // Marker for Docker integratino Tests
}
