package com.packtpub.mmj.booking.resources.docker;

/**
 *
 * @author Sourabh Sharma
 */
public interface DockerIT {
    // Marker for Docker integratino Tests
}
