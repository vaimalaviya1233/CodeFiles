package com.packtpub.mmj.user.resources.docker;

/**
 *
 * @author Sourabh Sharma
 */
public interface DockerIT {
    // Marker for Docker integratino Tests
}
