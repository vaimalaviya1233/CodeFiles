public class Exercise14 {
    public static void main(String[] args) {

        int i = 1;
        while (i < 10) {
            System.out.println("Odd: " + i);
            i += 2;
        }

    }
}
