public class Exercise11 {
    public static void main(String[] args) {

        for (int i = 1; i < 5; i++) {
            System.out.println("Iteration: " + i);
        }
    }

}

