public class Example21 {
    public static void main(String[] args) {

        var s = new String("Hello");
        System.out.println("The value is " + s);

        var i = Integer.valueOf("42");
        System.out.println("The value is " + i);

    }
}
