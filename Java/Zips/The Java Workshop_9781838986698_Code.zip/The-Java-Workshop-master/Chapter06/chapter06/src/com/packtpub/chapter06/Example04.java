package com.packtpub.chapter06;

import java.time.LocalDateTime;

public class Example04 {
    public static void main(String[] args) {
        System.out.println("The end of time is: " + LocalDateTime.MAX);
    }
}
