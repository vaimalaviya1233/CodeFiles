public class Example04 {
    public static void main(String[] args) {
        String vehicleType = null;
        String vehicle = "car";

        if (vehicleType.equals(vehicle)) {
            System.out.println("it's a car");
        } else {
            System.out.println("it's not a car");
        }
    }
}
