public class Main {
    public static void main(String[] args) {
        System.out.println("This is text");
        System.out.println('A');
        System.out.println(53);
        System.out.println(23.08f);
        System.out.println(1.97);
        System.out.println(true);
    }
}
