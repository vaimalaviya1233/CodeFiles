public class Main {
    public static void main(String[] args) {
        String t = "";
        System.out.println(t);
        t = t + "Joe ... ";
        System.out.println(t);
        t = t + "went fishing";
        System.out.println(t);
    }
}

