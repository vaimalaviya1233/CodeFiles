import React from 'react';
import Bot from './components/bot/bot';
import './App.css';
import './css/styles.css'

function App() {
  return (
    <>
      <h1>Banter with the Bard</h1>
      <Bot />
    </>
  );
}

export default App;
