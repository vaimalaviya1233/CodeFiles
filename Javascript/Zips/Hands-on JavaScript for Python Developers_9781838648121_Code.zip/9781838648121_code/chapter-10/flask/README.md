# Flask Example

Based on https://pythonspot.com/flask-web-forms/