const CONSTANTS = {
    //API_ROOT: "http://localhost:5000"
    API_ROOT: ""
}

export default CONSTANTS