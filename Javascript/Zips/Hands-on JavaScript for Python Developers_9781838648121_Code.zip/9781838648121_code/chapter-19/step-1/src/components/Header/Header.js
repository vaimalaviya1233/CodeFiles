import React from 'react'

function Header() {
  return (
    <>
      <h2>Chris Newman's</h2>
      <h1>Travelogue</h1>
    </>
  )
}
export default Header