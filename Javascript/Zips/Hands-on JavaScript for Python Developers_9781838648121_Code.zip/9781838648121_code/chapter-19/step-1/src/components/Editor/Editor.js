import React from 'react'

function Editor() {
  return (
    <>
      <h1>Editor</h1>
    </>
  )
}
export default Editor