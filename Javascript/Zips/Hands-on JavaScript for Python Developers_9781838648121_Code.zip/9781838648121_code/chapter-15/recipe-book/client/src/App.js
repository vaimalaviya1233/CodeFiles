import React from 'react'
import RecipeBook from './components/recipebook/RecipeBook'
import './App.css'

function App() {
  return (
    <div className="App">
      <RecipeBook />
    </div>
  )
}

export default App
