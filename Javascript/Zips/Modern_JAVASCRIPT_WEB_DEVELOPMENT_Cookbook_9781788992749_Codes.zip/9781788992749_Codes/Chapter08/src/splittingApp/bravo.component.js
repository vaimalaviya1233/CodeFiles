/* @flow */

import React from "react";

const Bravo = () => <h1>Bravo</h1>;

export default Bravo;
