/* @flow */

import React from "react";

const Charlie = () => <h1>Charlie</h1>;

export default Charlie;
