/* @flow */

import { SassButton } from "./sassButton.a11y";
export { SassButton };
