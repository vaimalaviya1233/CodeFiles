/* @flow */

import { I18nForm } from "./i18nform.js";
export { I18nForm };
