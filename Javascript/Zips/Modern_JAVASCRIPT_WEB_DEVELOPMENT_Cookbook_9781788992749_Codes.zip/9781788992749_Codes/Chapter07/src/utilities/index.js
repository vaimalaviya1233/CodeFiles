import { keyToClick } from "./keyToClick";

export { keyToClick };
