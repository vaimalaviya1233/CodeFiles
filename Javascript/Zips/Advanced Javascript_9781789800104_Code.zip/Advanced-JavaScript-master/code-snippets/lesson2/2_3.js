TwitterAPI.listFollowers( { user_id: 'example_user' }, (err, result) => {
  console.log( err, result );
} );