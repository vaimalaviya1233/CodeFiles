// Referenced before declaration
console.log( example ); // Expect ReferenceError because example is not defined
const example = 'example';
