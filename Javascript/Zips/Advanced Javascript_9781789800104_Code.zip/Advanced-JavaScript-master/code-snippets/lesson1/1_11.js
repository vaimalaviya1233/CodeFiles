// No arguments passed into the function
( ) => { /* Do function stuff here */ }
