const example = 'pretty';
console.log( `Template literals are ${ example } useful!!!` );
// Expected output: Template literals are pretty useful!!!
