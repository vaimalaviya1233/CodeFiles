class House {}
class Mansion extends House {}
