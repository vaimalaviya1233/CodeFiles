// Referenced before declaration
console.log( example ); // Expect output: undefined
var example = 'example';
