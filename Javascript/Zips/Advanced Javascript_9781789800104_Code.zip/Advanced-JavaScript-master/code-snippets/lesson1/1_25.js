const varName = 'firstName';
const person = {
  [ varName ]: 'John',
lastName: 'Smith'
};
console.log( person.firstName ); // Expected output: John
