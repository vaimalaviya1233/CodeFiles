// With return keyword - not necessary
let tmp = ( num1, num2 ) => { return ( num1 + num2 ) } // If called with arguments num1 = 5 and num2 = 5, expected output is 10

// Without return keyword or braces
tmp = ( num1, num2 ) => num1 + num2 // If called with arguments num1 = 5 and num2 = 5, expected output is 10
