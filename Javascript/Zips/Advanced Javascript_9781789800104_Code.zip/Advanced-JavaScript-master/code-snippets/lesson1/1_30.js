let [ a = 1, b = 2, c = 3 ] = [ 'cat', null ];
console.log( a ); // Expected output: 'cat'
console.log( b ); // Expected output: null
console.log( c ); // Expected output: 3
