// Referenced before declaration
console.log( example ); // Expect ReferenceError because example is not defined
let example = 'example';
