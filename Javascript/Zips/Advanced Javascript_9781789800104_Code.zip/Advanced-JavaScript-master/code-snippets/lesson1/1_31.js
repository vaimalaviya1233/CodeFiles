let a = 10;
let b = 5;

[ a, b ] = [ b, a ];

console.log( a ); // Expected output: 5
console.log( b ); // Expected output: 10
