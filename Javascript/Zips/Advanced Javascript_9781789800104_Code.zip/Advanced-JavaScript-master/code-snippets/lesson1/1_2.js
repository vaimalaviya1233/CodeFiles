example = 5; // Assign value
console.log( example ); // Expect output: 5
var example; // Declare variable
