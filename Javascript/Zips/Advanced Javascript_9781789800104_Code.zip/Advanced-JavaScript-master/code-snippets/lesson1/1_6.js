// Declared and initialized
let example = { prop1: 'test' };
console.log( 'example:', example ); // Expect output: example: {prop1: 'test'}
// Value reassigned
example = 5;
console.log( example ); // Expect output: 5
