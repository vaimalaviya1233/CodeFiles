describe( 'Array', () => {
  before( 'description', done => { } );
  after( 'description', done => { } );
  beforeEach( 'description', done => { } );
  afterEach( 'description', done => { } );
} );
