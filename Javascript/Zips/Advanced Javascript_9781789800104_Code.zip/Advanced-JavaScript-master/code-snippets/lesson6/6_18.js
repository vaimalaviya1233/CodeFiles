app.get( '/fo+d', ( req, res ) => {
console.log( 'Matched /fod, /food, /foood, /fooooooooood' );
} );