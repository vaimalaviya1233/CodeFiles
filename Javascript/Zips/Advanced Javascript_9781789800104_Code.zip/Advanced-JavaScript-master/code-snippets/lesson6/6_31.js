class ConstructorExample extends React.Component{
  constructor( props ){
    super( props );
    this.variable = 'test';
  }
  render() { return <div>Constructor Example</div>; }
}
