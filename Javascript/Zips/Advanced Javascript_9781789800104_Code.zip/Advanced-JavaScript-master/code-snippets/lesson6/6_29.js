const name = "David";
function multiplyBy2( num ) { return num * 2; }
const element1 = <div>Hello {name}!</div>;
const element2 = <div>6 * 2 = {multiplyBy2(6)}</div>;
