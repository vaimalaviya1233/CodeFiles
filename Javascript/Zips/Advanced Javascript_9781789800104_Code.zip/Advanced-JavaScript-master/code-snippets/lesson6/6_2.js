module.exports = {
  exportedVariable,
  exportedFn
};

const exportedVariable = 10;
function exportedFn( args ){ console.log( 'exportedFn' ) ;}
