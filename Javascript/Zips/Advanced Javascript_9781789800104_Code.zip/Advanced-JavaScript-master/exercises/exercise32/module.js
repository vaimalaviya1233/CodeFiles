module.exports = {
  exportedString: 'An exported string!',
  exportedFunction(){ console.log( 'An exported function!' ) }
};
