const ourModule = require('./module.js');
console.log( ourModule.exportedString );
ourModule.exportedFunction();
