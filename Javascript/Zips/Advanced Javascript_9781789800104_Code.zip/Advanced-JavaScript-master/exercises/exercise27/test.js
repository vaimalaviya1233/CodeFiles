'use strict';

describe( 'My first test!', () => {

  it( 'Passing test!', () => {} );

} );
